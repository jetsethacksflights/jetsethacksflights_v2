
Jetset Hacks — Full Repo (Ready for Git + Netlify)
=================================================
1) Create a new GitHub repo (e.g. jetsethacksflights_v2) and upload **all files** from this folder.
2) Netlify → Add new site → Import from Git → select the repo. Publish directory = `.`
3) GitHub → Settings → Secrets → Actions: add `NETLIFY_BUILD_HOOK_URL` and optionally `PROVIDER_API_KEY`.
4) Run the GitHub Action “Scrape flights & deploy” once.
5) Visit the site with `?bust=1` once after first deploy.

Feature flags live in `/config/features.json`.

Generated: 2025-08-17T01:50:05.981914Z
