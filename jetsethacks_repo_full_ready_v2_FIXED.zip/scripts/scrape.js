
// Replace MOCK with real provider fetches; keep this shape.
const fs=require('fs'); const path=require('path'); function nowISO(){return new Date().toISOString()}
const out=path.join(process.cwd(),'data'); if(!fs.existsSync(out)) fs.mkdirSync(out,{recursive:true});
const MOCK=[{depart:"2025-09-03",return_date:"2025-09-10",rt:true,from:"BNE",to:"CNS",airline:"Qantas",operator:"Qantas",marketing_flight:"QF389",operating_flight:"QF389",cabin:"Economy",price:{amount:332.00,currency:"USD"},points:4389,book_url:"",alliance:"Oneworld",source:"MOCK",last_checked:nowISO()}];
fs.writeFileSync(path.join(out,'flights.json'),JSON.stringify({generated_at:nowISO(),currency:"mixed",results:MOCK},null,2));
fs.writeFileSync(path.join(out,'providers.json'),JSON.stringify({providers:[{name:"Kiwi",status:"ok",latency_ms:420},{name:"Amadeus",status:"slow",latency_ms:1350}],checked_at:nowISO()},null,2));
fs.writeFileSync(path.join(out,'fx.json'),JSON.stringify({base:"AUD",rates:{AUD:1,USD:1.55,JPY:0.010,EUR:1.67,GBP:1.96},updated:nowISO().slice(0,10)},null,2));
console.log("Wrote data/*.json");
