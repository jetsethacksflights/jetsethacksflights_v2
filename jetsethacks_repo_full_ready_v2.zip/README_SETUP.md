
Jetset Hacks — Full Repo (Ready for Git + Netlify)
=================================================

This is a complete codebase. Use it by creating a **new GitHub repo** and pasting all files in.

Quick steps
-----------
1) Create a new GitHub repo (e.g., `jetsethacksflights_v2`). Keep your old repo as backup.
2) Upload **all files/folders** from this zip into the new repo root and commit.
3) Netlify → **Add new site → Import from Git** → pick this new repo.
4) In GitHub → Settings → Secrets → Actions:
   - `NETLIFY_BUILD_HOOK_URL` = your Netlify build hook URL (Site settings → Build & deploy → Build hooks → Add build hook).
   - `PROVIDER_API_KEY` = any provider key your scraper needs (optional).
5) GitHub → Actions → run “Scrape flights & deploy” once to seed `data/*.json`.
6) Visit the site → add `?bust=1` once to refresh assets; `?nosw=1` to clear SW if needed.

Feature flags
-------------
Turn features on/off without code edits by updating `/config/features.json`:
```json
{
  "boards": true,
  "nearbyAirports": true,
  "detailsDrawer": true,
  "currencyToggle": true,
  "languageToggle": true,
  "multiCityStub": false
}
```
(The app reads this on load; safe defaults are on.)

Data contract
-------------
See `/data/flights.json` for schema; the Netlify function `/api/flights` also reads these files.

Deployed: 2025-08-17T01:37:27.757149Z
